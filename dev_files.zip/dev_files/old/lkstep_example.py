from ldpop import rhos_from_string

a = rhos_from_string("11,10")

b = rhos_from_string("0,0.01,1,1,100")

print(f"{a=}")

print(f"{b=}")